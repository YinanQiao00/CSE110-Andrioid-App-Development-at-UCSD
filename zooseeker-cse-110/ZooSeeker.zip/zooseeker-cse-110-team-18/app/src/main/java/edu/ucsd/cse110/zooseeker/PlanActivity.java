package edu.ucsd.cse110.zooseeker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;

import edu.ucsd.cse110.zooseeker.data.ZooData;
import edu.ucsd.cse110.zooseeker.event.PlanUpdateListener;
import edu.ucsd.cse110.zooseeker.util.plan.PlanUtil;

public class PlanActivity extends AppCompatActivity implements PlanUpdateListener {
    TextView exhibit_count;
    Button btn_add;
    ImageButton btn_back;
    Button btn_clear;
    Button btn_plan_start;

    @Override
    protected void onResume() {
        super.onResume();
        PlanUtil.updateThisListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        PlanUtil.unregisterPlanUpdateListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onPlanChanged(List<ZooData.VertexInfo> newPlan) {
        runOnUiThread(() -> {
            exhibit_count.setText(String.valueOf(newPlan.size()));
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);

        PlanUtil.registerPlanUpdateListener(this);

        findLayoutComponents();
        setEventListeners(this);
    }

    private void findLayoutComponents() {
        exhibit_count = (TextView)findViewById(R.id.num_exhibits);
        btn_clear = findViewById(R.id.clear_button);
        btn_back = (ImageButton)findViewById(R.id.plan_back_button);
        btn_plan_start = findViewById(R.id.Start_Plan_button);
    }

    private void setEventListeners(Context context) {
        btn_clear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                new AlertDialog.Builder(context).setTitle("Warning").setMessage("Are you sure you want to clear the current plan")
                    .setPositiveButton("Yes", (dialog, id) -> {
                        PlanUtil.clear();
                    }).setNegativeButton("No", (dialog, id) -> {
                        dialog.cancel();
                }).setCancelable(true).create().show();
            }
        });
        btn_back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });
        btn_plan_start.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(PlanUtil.list_num() > 0) {
                    Intent navigationIntent = new Intent(v.getContext(), NavigationActivity.class);
                    v.getContext().startActivity(navigationIntent);
                }
            }
        });
    }
}