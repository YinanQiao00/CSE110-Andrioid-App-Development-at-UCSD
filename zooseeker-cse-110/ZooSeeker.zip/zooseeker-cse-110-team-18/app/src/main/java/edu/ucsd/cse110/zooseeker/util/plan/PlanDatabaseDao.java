package edu.ucsd.cse110.zooseeker.util.plan;

import androidx.annotation.NonNull;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.PrimaryKey;
import androidx.room.Query;

import java.util.List;

@Dao
public interface PlanDatabaseDao {

	@Insert
	long add(PlanItem item);

	@Insert
	List<Long> addAll(List<PlanItem> items);

	@Query("SELECT * FROM `planned_exhibits` WHERE `id`=:id")
	public PlanItem get(long id);

	@Query("SELECT * FROM `planned_exhibits` WHERE `exhibitId`=:exhibitId")
	public PlanItem get(@NonNull String exhibitId);

	@Query("SELECT * FROM `planned_exhibits` ORDER BY `exhibitId`")
	public List<PlanItem> getAll();

	@Delete
	public int remove(PlanItem item);

	@Query("SELECT COUNT(`id`) FROM `planned_exhibits`")
	public int size();


	@Query("DELETE FROM `planned_exhibits`")
	public void clear();

}
