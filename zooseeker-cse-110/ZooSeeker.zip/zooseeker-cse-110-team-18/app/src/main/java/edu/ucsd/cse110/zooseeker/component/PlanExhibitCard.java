package edu.ucsd.cse110.zooseeker.component;public class PlanExhibitCard {
}
