package edu.ucsd.cse110.zooseeker.util;

public class Constants {
	public static final String NODE_FILE_NAME = "sample_node_info.json";
	public static final String EDGE_FILE_NAME = "sample_edge_info.json";
	public static final String GRAPH_FILE_NAME = "sample_zoo_graph.json";
}
