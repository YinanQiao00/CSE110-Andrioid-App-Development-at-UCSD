package edu.ucsd.cse110.zooseeker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;

import org.jgrapht.GraphPath;

import java.util.List;
import java.util.stream.Collectors;

import edu.ucsd.cse110.zooseeker.data.DataManager;
import edu.ucsd.cse110.zooseeker.data.ZooData;
import edu.ucsd.cse110.zooseeker.data.graph.IdentifiedWeightedEdge;
import edu.ucsd.cse110.zooseeker.event.PlanUpdateListener;
import edu.ucsd.cse110.zooseeker.event.PositionEventListener;
import edu.ucsd.cse110.zooseeker.event.SettingsUpdateListener;
import edu.ucsd.cse110.zooseeker.util.plan.PlanUtil;

public class NavigationActivity extends AppCompatActivity implements PlanUpdateListener, PositionEventListener, SettingsUpdateListener {
	public static final String SPREF_NAVIGATION_INDEX = "navigation_index";
	DataManager dataManager;

	int index = 0;
	List<ZooData.VertexInfo> plan;
	List<GraphPath<String, IdentifiedWeightedEdge>> path;

	TextView fromTitle;
	TextView toTitle;
	TextView directions;
	RecyclerView recycler;

	Button backBtn;
	Button nextBtn;
	Button endPlanBtn;

	public static int loadIndex(Context context)
	{
		SharedPreferences sharedPreferences = context.getSharedPreferences("shared preferences", context.MODE_PRIVATE);
		return sharedPreferences.getInt(SPREF_NAVIGATION_INDEX,-1);
	}

	public static void saveIndex(Context context, int index)
	{
		SharedPreferences sharedPreferences = context.getSharedPreferences("shared preferences", context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putInt(SPREF_NAVIGATION_INDEX, index);
		editor.commit();
	}

	@Override
	protected void onResume() {
		super.onResume();
		index = loadIndex(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		saveIndex(this, index);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		saveIndex(this, index);
	}

	//Currently unnecessary
	@Override
	public void onPlanChanged(List<ZooData.VertexInfo> newPlan) {
		this.plan = newPlan;
	}

	@Override
	public void positionUpdate(LatLng newPos) {
		//Perform necessary actions using newPos
	}

	@Override
	public void onSettingsUpdate(String key, String value) {
		//Perform necessary actions using new settings (key,value)
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_navigation);

		getRoute();

		findLayoutComponents();

		setEventListeners(this);

		indexUpdated();
	}

	private void getRoute() {
		dataManager = DataManager.getInstance(this);
		path = dataManager.navigation.findShortestPaths(dataManager.search.getByType(ZooData.VertexInfo.Kind.GATE).get(0).id,
				plan.stream().map(item -> item.id).collect(Collectors.toSet()));
		index = loadIndex(this);
		if(index < 0 || index > path.size()-1) {
			index = 0;
			saveIndex(this, index);
		}
	}

	private void findLayoutComponents() {
		fromTitle = findViewById(R.id.fromTitle);
		toTitle = findViewById(R.id.toTitle);
		directions = findViewById(R.id.pathDirections);
		recycler = findViewById(R.id.planRecycler);
		backBtn = findViewById(R.id.backBtn);
		nextBtn = findViewById(R.id.nextBtn);
		endPlanBtn = findViewById(R.id.endPlanBtn);
	}

	private void setEventListeners(Context context) {
		backBtn.setOnClickListener((view) -> {
			index = Math.max(0,index-1);
			indexUpdated();
		});
		nextBtn.setOnClickListener((view) -> {
			if(index < 0)
				index = 0;
			index = Math.min(path.size()-1,index+1);
			indexUpdated();
		});
		endPlanBtn.setOnClickListener((view) -> {
			if(index != path.size()-1) {
				new AlertDialog.Builder(context).setTitle("Warning").setMessage("You will lose your navigation progress")
						.setPositiveButton("Ok", (dialog, id) -> {
							dialog.dismiss();
							index = -1;
							saveIndex(this, -1);
							finish();
						}).setNegativeButton("Cancel", (dialog, id) -> {
					dialog.cancel();
				}).setCancelable(true).create().show();
			}
			else
			{
				index = -1;
				saveIndex(this,-1);
				finish();
			}
		});
	}

	private void indexUpdated()
	{
		GraphPath<String,IdentifiedWeightedEdge> p = path.get(index);
		fromTitle.setText(dataManager.vertexInfoMap.get(p.getStartVertex()).name);
		toTitle.setText(dataManager.vertexInfoMap.get(p.getEndVertex()).name);
		String dirs = PlanUtil.PathFormatter.pathToText(p, dataManager);
		dirs = dirs.substring(0,dirs.length()-1).replace("\n","\n\n");
		directions.setText(dirs);

		backBtn.setVisibility(index == 0 ? View.INVISIBLE : View.VISIBLE);
		nextBtn.setText(index == path.size()-1 ? "End Reached" : "Next");
		nextBtn.setEnabled(index != path.size()-1);
		nextBtn.setBackgroundDrawable(index == path.size()-1 ? getResources().getDrawable(R.drawable.button_style_disabled):
				getResources().getDrawable(R.drawable.button_style_add));
	}
}