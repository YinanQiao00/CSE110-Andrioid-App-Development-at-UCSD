package edu.ucsd.cse110.zooseeker.map;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;

import edu.ucsd.cse110.zooseeker.event.PositionEventListener;

public class PositionUpdater {

	private static final List<PositionEventListener> listeners = new ArrayList<>();

	public static void registerPlanUpdateListener(PositionEventListener listener)
	{
		if(!listeners.contains(listener)) {
			listeners.add(listener);
		}
	}
	public static void unregisterPlanUpdateListener(PositionEventListener listener)
	{
		if(listeners.contains(listener))
			listeners.remove(listener);
	}
	public static void updateListeners(LatLng newPos)
	{
		for(PositionEventListener listener : listeners)
			listener.positionUpdate(newPos);
	}

	//Implement code to call updateListeners() as necessary

}
