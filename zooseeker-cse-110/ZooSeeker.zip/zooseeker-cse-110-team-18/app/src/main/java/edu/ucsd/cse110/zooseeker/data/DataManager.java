package edu.ucsd.cse110.zooseeker.data;

import android.content.Context;

import androidx.annotation.Nullable;

import org.jgrapht.Graph;

import java.util.Map;

import edu.ucsd.cse110.zooseeker.data.graph.INavigation;
import edu.ucsd.cse110.zooseeker.data.graph.IdentifiedWeightedEdge;
import edu.ucsd.cse110.zooseeker.data.graph.ZooNavigation;
import edu.ucsd.cse110.zooseeker.data.search.ISearch;
import edu.ucsd.cse110.zooseeker.data.search.ZooSearch;
import edu.ucsd.cse110.zooseeker.util.Constants;

public class DataManager {

	private static DataManager instance = null;

	public Map<String, ZooData.VertexInfo> vertexInfoMap;
	public Map<String, ZooData.EdgeInfo> edgeInfoMap;
	public Graph<String, IdentifiedWeightedEdge> graph;

	public ISearch search = null;
	public INavigation navigation = null;

	@Nullable
	public static DataManager getInstance()
	{
		return instance;
	}

	public static DataManager getInstance(Context context)
	{
		if(instance == null)
			DataManager.instantiate(context, Constants.NODE_FILE_NAME, Constants.EDGE_FILE_NAME, Constants.GRAPH_FILE_NAME, ZooSearch.class, ZooNavigation.class);
		return instance;
	}

	public static DataManager instantiate(Context context, String vertexInfoPath, String edgeInfoPath, String graphPath, Class<? extends ISearch> searchClazz, Class<? extends INavigation> navigationClazz)
	{
		if(instance == null) {
			try {
				instance = new DataManager(context, vertexInfoPath, edgeInfoPath, graphPath, searchClazz, navigationClazz);
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			}
		}
		return instance;
	}

	private DataManager(Context context, String vertexInfoPath, String edgeInfoPath, String graphPath, Class<? extends ISearch> searchClazz, Class<? extends INavigation> navigationClazz) throws IllegalAccessException, InstantiationException {
		vertexInfoMap = ZooData.loadVertexInfoJSON(context, vertexInfoPath);
		edgeInfoMap = ZooData.loadEdgeInfoJSON(context, edgeInfoPath);
		graph = ZooData.loadZooGraphJSON(context, graphPath);

		search = searchClazz.newInstance().reloadData(vertexInfoMap);
		navigation = navigationClazz.newInstance().reloadData(graph);
	}

}
