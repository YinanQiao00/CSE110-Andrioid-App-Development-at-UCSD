package edu.ucsd.cse110.zooseeker.util.plan;


import android.util.Log;

import androidx.annotation.NonNull;

import org.jgrapht.GraphPath;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import edu.ucsd.cse110.zooseeker.data.DataManager;
import edu.ucsd.cse110.zooseeker.data.ZooData;
import edu.ucsd.cse110.zooseeker.data.graph.IdentifiedWeightedEdge;
import edu.ucsd.cse110.zooseeker.event.PlanUpdateListener;

public class PlanUtil {

	private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final List<PlanUpdateListener> listeners = new ArrayList<>();

    public static void registerPlanUpdateListener(PlanUpdateListener listener)
    {
        if(!listeners.contains(listener)) {
            listeners.add(listener);
        }
		Future<Void> future = executor.submit(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			listener.onPlanChanged(Collections.unmodifiableList(getPlanFromDao(dao)));
			return null;
		});
		while(!future.isDone());
    }
    public static void unregisterPlanUpdateListener(PlanUpdateListener listener)
    {
        if(listeners.contains(listener))
            listeners.remove(listener);
    }
    public static void updateListeners()
    {
		executor.execute(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			updateListeners(Collections.unmodifiableList(getPlanFromDao(dao)));
		});
    }
    private static void updateListeners(List<ZooData.VertexInfo> list)
    {
        for(PlanUpdateListener listener : listeners)
            listener.onPlanChanged(list);
    }
	public static void updateThisListener(PlanUpdateListener listener)
	{
		executor.execute(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			listener.onPlanChanged(Collections.unmodifiableList(getPlanFromDao(dao)));
		});
	}

    // add exhibit to plan by ID
    public static void add(String id) {
		executor.execute(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			PlanItem exists = dao.get(id);
			if(exists == null)
				dao.add(new PlanItem(id));
			updateListeners(getPlanFromDao(dao));
		});
    }

	@NonNull
	private static List<ZooData.VertexInfo> getPlanFromDao(PlanDatabaseDao dao) {
		return dao.getAll().stream()
				.map(item -> DataManager.getInstance().vertexInfoMap.get(item.exhibitId))
				.collect(Collectors.toList());
	}

	// remove exhibit from plan by ID
    public static void remove(String id){
		executor.execute(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			PlanItem toRemove = dao.get(id);
			if(toRemove != null)
				dao.remove(toRemove);

			updateListeners(getPlanFromDao(dao));
		});
    }

    // removes all exhibits from the list
    public static void clear(){
		executor.execute(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			dao.clear();

			updateListeners(getPlanFromDao(dao));
		});
    }

    // returns the size of list
    public static int list_num(){
		Future<Integer> future = executor.submit(() -> {
			PlanDatabaseDao dao = PlanDatabase.getInstance(null).getDao();
			return dao.size();
		});
		while(!future.isDone());

		try {
			return future.get();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return -1;
	}

	public static class PathFormatter {

		public static List<Double> getCumulativeDistance(List<GraphPath<String, IdentifiedWeightedEdge>> paths, int startIndex)
		{
			List<Double> ret = new ArrayList<Double>();

			double distance = 0;
			for(int i = startIndex; i < paths.size(); i++)
			{
				distance += paths.get(i).getWeight();
				ret.add(distance);
			}
			return ret;
		}


		public static List<String> getVertexIdOrder(List<GraphPath<String, IdentifiedWeightedEdge>> paths, int startIndex)
		{
			List<String> ret = new ArrayList<String>();

			for(int i = startIndex; i < paths.size(); i++){
				ret.add((String) paths.get(i).getEndVertex());
			}
			return ret;
		}

		public static List<String> getEndEdgeIdOrder(List<GraphPath<String, IdentifiedWeightedEdge>> paths, int startIndex, DataManager dataManager) {
			List<String> ret = new ArrayList<String>();

			for(int i = startIndex; i < paths.size(); i++){
				ret.add(dataManager.edgeInfoMap.get(paths.get(i).getEdgeList().get(paths.get(i).getEdgeList().size() - 1).getId()).street);
			}
			return ret;

		}

		public static List<String> exhibitsDistanceFormat(List<String> vertexOrder, List<Double> distanceOrder, List<String> endEdgeOrder) {
			String info = "";
			List<String> ret = new ArrayList<String>();
			if (!(vertexOrder.size() == distanceOrder.size() && distanceOrder.size() == endEdgeOrder.size())) {
				// something went wrong
				//the 3 lists are not equal in length
				ret.add("SOMETHING WENT WRONG! THE 3 LISTS ARE NOT EQUAL IN LENGTH!\n");
				return ret;
			}
			for (int i = 0; i < vertexOrder.size(); i++) {
				info = vertexOrder.get(i) + ",  " + String.valueOf(distanceOrder.get(i)) + " ft,  " + endEdgeOrder.get(i) + "\n";
				ret.add(info);
			}

			return ret;
		}


		public static String pathToText(GraphPath<String, IdentifiedWeightedEdge> path, DataManager dataManager)
		{
			String result = "";

			int i = 1;

			for (IdentifiedWeightedEdge e : path.getEdgeList()) {
				result += String.format("(%d) Walk %.0f ft along %s from '%s' to '%s'.\n",
						i,
						dataManager.graph.getEdgeWeight(e),
						dataManager.edgeInfoMap.get(e.getId()).street,
						dataManager.vertexInfoMap.get(dataManager.graph.getEdgeSource(e).toString()).name,
						dataManager.vertexInfoMap.get(dataManager.graph.getEdgeTarget(e).toString()).name);
				i++;
			}
			return result;
		}
	}
}
