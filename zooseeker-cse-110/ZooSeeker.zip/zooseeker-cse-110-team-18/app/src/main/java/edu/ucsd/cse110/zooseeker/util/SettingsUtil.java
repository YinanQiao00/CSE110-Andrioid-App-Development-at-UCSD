package edu.ucsd.cse110.zooseeker.util;

import java.util.ArrayList;
import java.util.List;

import edu.ucsd.cse110.zooseeker.event.SettingsUpdateListener;

public class SettingsUtil {
	private static final List<SettingsUpdateListener> listeners = new ArrayList<>();

	public static void registerSettingsUpdateListener(SettingsUpdateListener listener)
	{
		if(!listeners.contains(listener)) {
			listeners.add(listener);
		}
	}
	public static void unregisterSettingsUpdateListener(SettingsUpdateListener listener)
	{
		if(listeners.contains(listener))
			listeners.remove(listener);
	}
	private static void updateListeners(String key, String value)
	{
		for(SettingsUpdateListener listener : listeners)
			listener.onSettingsUpdate(key, value);
	}

	public void set(String key, String value)
	{
		//STUB
		//Perform necessary actions to update/save new settings (key,value)

		updateListeners(key, value);
	}

	public String get(String key)
	{
		//STUB
		//Perform necessary actions to return current value associated with key

		return null;
	}

}
