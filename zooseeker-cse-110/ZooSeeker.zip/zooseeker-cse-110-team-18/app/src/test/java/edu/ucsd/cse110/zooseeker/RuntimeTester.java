package edu.ucsd.cse110.zooseeker;

import static org.junit.Assert.fail;

import androidx.lifecycle.Lifecycle;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.ucsd.cse110.zooseeker.data.graph.INavigation;
import edu.ucsd.cse110.zooseeker.data.graph.ZooNavigation;
import edu.ucsd.cse110.zooseeker.data.search.ISearch;
import edu.ucsd.cse110.zooseeker.data.search.ZooSearch;
import edu.ucsd.cse110.zooseeker.data.test.EmptyActivity;

@Ignore
@RunWith(AndroidJUnit4.class)
public class RuntimeTester {

	private final long N = 50;

	@Rule
	public ActivityScenarioRule rule = new ActivityScenarioRule<>(EmptyActivity.class);

	private long timePassed(Runnable task)
	{
		long time = System.currentTimeMillis();
		task.run();
		return System.currentTimeMillis()-time;
	}

	@Test
	public void testRuntimeLoadZooSearch()
	{
		ActivityScenario scene = rule.getScenario();
		scene.moveToState(Lifecycle.State.CREATED);
		Runnable task = () -> {
			scene.onActivity( activity -> {
				ISearch search = ZooSearch.createInstance(activity, "large_test_node_info.json");
			});
		};

		long peak = 0;
		long sum = 0;
		for(int i = 0; i < N; i++)
		{
			long time = timePassed(task);
			if(time > peak)
				peak = time;
			sum += time;
		}
		fail(String.format("Average: %d, Peak: %d", sum/N, peak));
	}

	@Test
	public void testRuntimeNavigationCreate()
	{
		ActivityScenario scene = rule.getScenario();
		scene.moveToState(Lifecycle.State.CREATED);
		Runnable task = () -> {
			scene.onActivity( activity -> {
				INavigation navigator = ZooNavigation.createInstance(activity, "large_test_graph.json");
			});
		};

		long peak = 0;
		long sum = 0;
		for(int i = 0; i < N; i++)
		{
			long time = timePassed(task);
			if(time > peak)
				peak = time;
			sum += time;
		}
		fail(String.format("Average: %d, Peak: %d", sum/N, peak));
	}

	@Test
	public void testRuntimeNavigationFindPath()
	{
		ActivityScenario scene = rule.getScenario();
		scene.moveToState(Lifecycle.State.CREATED);
		scene.onActivity( activity -> {
			INavigation navigator = ZooNavigation.createInstance(activity, "large_test_graph.json");

			Set<String> t = new HashSet<String>();
			for(int i = 1; i < 50; i++)
				t.add(""+i);
			Runnable task = () -> {
				Set<String> targets = new HashSet<String>();
				targets.addAll(t);
				navigator.findShortestPaths("0", targets);
			};

			long peak = 0;
			long sum = 0;
			for(int i = 0; i < 1; i++)
			{
				long time = timePassed(task);
				if(time > peak)
					peak = time;
				sum += time;
			}
			fail(String.format("Average: %d, Peak: %d", sum/N, peak));
		});
	}

}
